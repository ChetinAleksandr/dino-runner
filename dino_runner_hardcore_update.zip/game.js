
(() => {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const $ = id => document.getElementById(id);
  const W = canvas.width, H = canvas.height, GROUND = 338;

  const skins = [
    { name:'Классика', note:'Зелёный', body:'#78bd55', belly:'#d7e8a6', shade:'#477d3d', eye:'#17251c', spikes:'#d9e99a' },
    { name:'Огненный', note:'Янтарный', body:'#f18b42', belly:'#ffe0a4', shade:'#b84d32', eye:'#352017', spikes:'#ffe08a' },
    { name:'Космо', note:'Неоновый', body:'#8c83ed', belly:'#d8d4ff', shade:'#5148b7', eye:'#171633', spikes:'#72e7dc' }
  ];

  const seasons = [
    { name:'ВЕСНА', icon:'✿', sky1:'#8ed9e7', sky2:'#e3f7d5', hill1:'#80bd83', hill2:'#4f9a6b', ground:'#d4bd83' },
    { name:'ЛЕТО', icon:'☀', sky1:'#65c8ef', sky2:'#d8f5ef', hill1:'#83c86e', hill2:'#4e9b58', ground:'#d9bd79' },
    { name:'ОСЕНЬ', icon:'🍂', sky1:'#e99a66', sky2:'#f8d6a0', hill1:'#bd8756', hill2:'#8e704c', ground:'#b58a59' },
    { name:'ЗИМА', icon:'❄', sky1:'#789bc5', sky2:'#dcebf5', hill1:'#a9c6d7', hill2:'#779eb4', ground:'#e8f0f4' }
  ];

  // ======================================
// СИСТЕМА ДОСТИЖЕНИЙ — 30 НАГРАД
// ======================================

const achievements = [
  { name: 'Первый шаг', description: 'Набери 100 очков', score: 100 },
  { name: 'Разминка', description: 'Набери 250 очков', score: 250 },
  { name: 'Любопытный бегун', description: 'Набери 400 очков', score: 400 },
  { name: 'Не останавливайся', description: 'Набери 600 очков', score: 600 },
  { name: 'Первые трудности', description: 'Набери 850 очков', score: 850 },
  { name: 'На полной скорости', description: 'Набери 1 100 очков', score: 1100 },
  { name: 'Лесной следопыт', description: 'Набери 1 400 очков', score: 1400 },
  { name: 'Уверенный шаг', description: 'Набери 1 750 очков', score: 1750 },
  { name: 'Покоритель сезонов', description: 'Набери 2 100 очков', score: 2100 },
  { name: 'Быстрее ветра', description: 'Набери 2 500 очков', score: 2500 },
  { name: 'Неуловимый', description: 'Набери 3 000 очков', score: 3000 },
  { name: 'Испытание началось', description: 'Набери 3 600 очков', score: 3600 },
  { name: 'Хозяин тропы', description: 'Набери 4 200 очков', score: 4200 },
  { name: 'За горизонтом', description: 'Набери 4 900 очков', score: 4900 },
  { name: 'Мастер уклонений', description: 'Набери 5 700 очков', score: 5700 },
  { name: 'Без права на ошибку', description: 'Набери 6 500 очков', score: 6500 },
  { name: 'Скоростной зверь', description: 'Набери 7 400 очков', score: 7400 },
  { name: 'Легенда джунглей', description: 'Набери 8 300 очков', score: 8300 },
  { name: 'Предел возможностей', description: 'Набери 9 300 очков', score: 9300 },
  { name: 'Десять тысяч шагов', description: 'Набери 10 300 очков', score: 10300 },
  { name: 'Повелитель препятствий', description: 'Набери 11 400 очков', score: 11400 },
  { name: 'Невероятная выносливость', description: 'Набери 12 500 очков', score: 12500 },
  { name: 'За гранью скорости', description: 'Набери 13 700 очков', score: 13700 },
  { name: 'Последний рубеж', description: 'Набери 14 900 очков', score: 14900 },
  { name: 'Невозможное возможно', description: 'Набери 16 100 очков', score: 16100 },
  { name: 'Вечный бегун', description: 'Набери 17 300 очков', score: 17300 },
  { name: 'Почти легенда', description: 'Набери 18 400 очков', score: 18400 },
  { name: 'На краю вечности', description: 'Набери 19 300 очков', score: 19300 },
  { name: 'Последняя дистанция', description: 'Набери 19 800 очков', score: 19800 },
  { name: 'Конец?', description: 'Набери 20 000 очков', score: 20000 }
];

// Загружаем открытые достижения
function loadAchievements() {
  try {
    const data = JSON.parse(
      localStorage.getItem('dinoAchievements')
    );

    if (Array.isArray(data)) {
      return achievements.map((_, i) => data[i] === true);
    }
  } catch (_) {}

  return achievements.map(() => false);
}

let unlockedAchievements = loadAchievements();

// Проверка достижений
function checkAchievements() {
  let changed = false;

  achievements.forEach((achievement, i) => {
    if (
      !unlockedAchievements[i] &&
      score >= achievement.score
    ) {
      unlockedAchievements[i] = true;
      changed = true;
    }
  });

  if (changed) {
    save(
      'dinoAchievements',
      JSON.stringify(unlockedAchievements)
    );
  }
}

// Отрисовка списка достижений
function renderAchievements() {
  const list = $('achievementsList');
  list.replaceChildren();

  const unlockedCount = unlockedAchievements.filter(Boolean).length;

  $('achievementProgress').textContent =
    `Открыто: ${unlockedCount} / 30`;
  $('secretAchievementCard').classList.toggle('unlocked', crownUnlocked);
  $('secretAchievementCard').querySelector('.achievement-icon').textContent =
    crownUnlocked ? '👑' : '❓';
  $('secretAchievementCard').querySelector('strong').textContent =
    crownUnlocked ? 'За гранью тумана' : '???';
  $('secretAchievementCard').querySelector('span').textContent =
    crownUnlocked ? 'Секретная корона получена' : 'Условие неизвестно';
  $('secretAchievementStatus').textContent =
    crownUnlocked ? 'ОТКРЫТО' : 'ЗАКРЫТО';

  achievements.forEach((achievement, i) => {
    const unlocked = unlockedAchievements[i];

    const item = document.createElement('div');
    item.className =
      'achievement-item' + (unlocked ? ' unlocked' : '');

    item.innerHTML = `
      <div class="achievement-icon">
        ${unlocked ? '🏆' : '🔒'}
      </div>

      <div class="achievement-info">
        <strong>${achievement.name}</strong>
        <span>${achievement.description}</span>
      </div>

      <div class="achievement-status">
        ${unlocked ? 'ОТКРЫТО' : 'ЗАКРЫТО'}
      </div>
    `;

    list.appendChild(item);
  });
}

  function stored(key, fallback) {
    try {
      const n = Number(localStorage.getItem(key));
      return Number.isFinite(n) && n >= 0 ? n : fallback;
    } catch (_) { return fallback; }
  }

  function save(key, value) {
    try { localStorage.setItem(key, String(value)); } catch (_) {}
  }

  function loadSkinRecords() {
  try {
    const data = JSON.parse(
      localStorage.getItem('dinoBestBySkin')
    );

    if (Array.isArray(data)) {
      return skins.map((_, i) => {
        const value = Number(data[i]);
        return Number.isFinite(value) && value >= 0
          ? value
          : 0;
      });
    }
  } catch (_) {}

  return skins.map(() => 0);
}

let skinIndex = Math.min(2, Math.floor(stored('dinoSkin', 0)));

let bestScores = loadSkinRecords();

// Общий рекорд всех скинов
let best = Math.max(
  stored('dinoBest', 0),
  ...bestScores
);

let hardcoreSelected = false;
let runHardcore = false;
let crownUnlocked = stored('dinoCrownUnlocked', 0) === 1;
let crownEquipped = stored('dinoCrownEquipped', 0) === 1;


  // Состояние игры
  let state = 'menu';

  let score = 0;
  let frame = 0;
  let distance = 0;
  let speed = 6;

  let seasonIndex = 1;
  let seasonBlend = 1;
  let previousSeasonIndex = seasonIndex;

  let obstacles = [];
  let particles = [];

  let keys = {};
  let lastTime = 0;

  // Игрок
  let player = {
    x: 90,
    y: GROUND,
    vy: 0,
    duck: false,
    grounded: true,
    run: 0,
    attackTimer: 0,
    attackType: 'kick'
  };

  // Полный сброс забега
  function resetRun() {
    score = 0;
    frame = 0;
    distance = 0;
    speed = 6;
    runHardcore = hardcoreSelected;

    seasonIndex = 1;
    seasonBlend = 1;

    obstacles = [];
    particles = [];
    keys = {};

    player = {
      x: 90,
      y: GROUND,
      vy: 0,
      duck: false,
      grounded: true,
      run: 0,
      attackTimer: 0,
      attackType: 'kick'
    };

    lastTime = 0;
    state = 'menu';

    updateHud();
  }


  
// Отрисовка динозаврика
function drawDino(g, x, y, skin, duck = false, run = 0, scale = 1) {
  g.save();
  g.translate(x, y);
  g.scale(scale, scale);

  const bob = (!duck && player && player.grounded)
    ? Math.sin(run * .22) * 1.8 : 0;

  g.translate(0, bob);

  const c = skin.body;
  const dark = skin.shade;
  const belly = skin.belly;

  // Хвост
  g.fillStyle = dark;
  g.beginPath();
  g.moveTo(16, -37);
  g.lineTo(-14, -30);
  g.lineTo(13, -22);
  g.closePath();
  g.fill();

  if (duck) {
    roundedRect(g, 2, -35, 62, 27, 12, c);
    roundedRect(g, 16, -27, 28, 13, 7, belly);
    roundedRect(g, 48, -43, 27, 25, 10, c);

    g.fillStyle = skin.spikes;
    g.beginPath();
    g.moveTo(50, -43);
    g.lineTo(58, -57);
    g.lineTo(65, -43);
    g.fill();

    g.fillStyle = skin.eye;
    g.beginPath();
    g.arc(65, -34, 2.8, 0, Math.PI * 2);
    g.fill();

    roundedRect(g, 13, -12, 13, 10, 4, dark);
    roundedRect(g, 43, -12, 13, 10, 4, dark);

    // Текстура при приседании
    if (skin.name === 'Классика') {
      g.fillStyle = '#a6d477';
      for (let i = 0; i < 4; i++) {
        g.beginPath();
        g.arc(12 + i * 10, -32, 2, 0, Math.PI * 2);
        g.fill();
      }
    } else if (skin.name === 'Огненный') {
      g.strokeStyle = '#9f3928';
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(22, -35);
      g.lineTo(29, -12);
      g.moveTo(39, -35);
      g.lineTo(46, -12);
      g.stroke();
    } else if (skin.name === 'Космо') {
      g.strokeStyle = '#72e7dc';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(12, -30);
      g.lineTo(35, -30);
      g.moveTo(20, -20);
      g.lineTo(42, -20);
      g.stroke();
    }
  } else {
    // Ноги с анимацией бега
    const phase = Math.sin(run * .32) * 5;

    roundedRect(g, 18, -23 + phase, 14, 24 - phase, 5, dark);
    roundedRect(g, 45, -23 - phase, 14, 24 + phase, 5, dark);

    // Тело и живот
    roundedRect(g, 9, -59, 55, 42, 14, c);
    roundedRect(g, 25, -48, 27, 26, 10, belly);

    // Голова
    roundedRect(g, 45, -82, 36, 34, 12, c);

    // Гребень
    g.fillStyle = skin.spikes;
    g.beginPath();
    g.moveTo(47, -79);
    g.lineTo(51, -94);
    g.lineTo(60, -80);
    g.lineTo(64, -98);
    g.lineTo(73, -80);
    g.closePath();
    g.fill();

    // Глаз
    g.fillStyle = skin.eye;
    g.beginPath();
    g.arc(70, -69, 3.4, 0, Math.PI * 2);
    g.fill();

    g.fillStyle = '#fff';
    g.beginPath();
    g.arc(71, -70, 1.1, 0, Math.PI * 2);
    g.fill();

    // Ноздря и улыбка
    g.fillStyle = dark;
    g.fillRect(78, -59, 4, 3);

    g.strokeStyle = dark;
    g.lineWidth = 2;
    g.beginPath();
    g.arc(73, -55, 7, .2, 1.2);
    g.stroke();

    // Рука
    roundedRect(g, 51, -37, 15, 7, 4, dark);

    // Уникальные текстуры каждого динозавра
    if (skin.name === 'Классика') {
      // Зелёные чешуйки на теле
      g.fillStyle = '#a6d477';

      for (let i = 0; i < 5; i++) {
        g.beginPath();
        g.arc(16 + i * 8, -52 + (i % 2) * 7, 2.2, 0, Math.PI * 2);
        g.fill();
      }

      // Маленькие спинные пластины
      g.fillStyle = '#d9e99a';
      for (let i = 0; i < 3; i++) {
        g.beginPath();
        g.moveTo(17 + i * 11, -59);
        g.lineTo(21 + i * 11, -67);
        g.lineTo(25 + i * 11, -59);
        g.closePath();
        g.fill();
      }

    } else if (skin.name === 'Огненный') {
      // Огненные полосы на теле
      g.strokeStyle = '#a83f2c';
      g.lineWidth = 4;
      g.lineCap = 'round';

      g.beginPath();
      g.moveTo(17, -57);
      g.lineTo(23, -39);

      g.moveTo(31, -59);
      g.lineTo(37, -39);

      g.moveTo(45, -57);
      g.lineTo(50, -43);
      g.stroke();

      // Янтарные пятна
      g.fillStyle = '#ffd16a';

      for (let i = 0; i < 4; i++) {
        g.beginPath();
        g.arc(17 + i * 9, -29 - (i % 2) * 5, 2.5, 0, Math.PI * 2);
        g.fill();
      }

    } else if (skin.name === 'Космо') {
      // Неоновые линии
      g.strokeStyle = '#72e7dc';
      g.lineWidth = 2;
      g.lineCap = 'round';

      g.beginPath();
      g.moveTo(15, -54);
      g.lineTo(28, -54);
      g.lineTo(34, -46);
      g.lineTo(47, -46);

      g.moveTo(15, -36);
      g.lineTo(25, -36);
      g.moveTo(40, -30);
      g.lineTo(51, -30);
      g.stroke();

      // Звёздочки
      g.fillStyle = '#ffffff';

      for (let i = 0; i < 4; i++) {
        const sx = 17 + i * 12;
        const sy = -58 + (i % 2) * 13;

        g.beginPath();
        g.arc(sx, sy, 1.8, 0, Math.PI * 2);
        g.fill();
      }

      // Светящаяся точка на голове
      g.fillStyle = '#72e7dc';
      g.beginPath();
      g.arc(56, -72, 2.5, 0, Math.PI * 2);
      g.fill();
    }
  }

  // Корона выбранного динозаврика
  if (crownEquipped && crownUnlocked && !duck) {
    g.save();
    g.translate(61, -84 + bob);
    g.fillStyle = '#ffd84d';
    g.strokeStyle = '#9a641d';
    g.lineWidth = 2;
    g.beginPath();
    g.moveTo(-13, -2);
    g.lineTo(-11, -16);
    g.lineTo(-4, -9);
    g.lineTo(1, -20);
    g.lineTo(7, -9);
    g.lineTo(13, -16);
    g.lineTo(14, -2);
    g.closePath();
    g.fill();
    g.stroke();
    g.fillStyle = '#fff2a6';
    g.fillRect(-11, 0, 24, 4);
    g.restore();
  }

  // Удар ногой: нога резко выбрасывается вперёд и возвращается
  if (player && player.attackTimer > 0 && !duck) {
    const phase = Math.max(0, 1 - player.attackTimer / 18);
    const kick = Math.sin(phase * Math.PI);
    g.save();
    g.translate(49, -22);
    g.rotate(-0.95 * kick);
    roundedRect(g, -2, -1, 31, 11, 5, dark);
    g.restore();
    // Короткая вспышка удара
    if (phase > .25 && phase < .8) {
      g.strokeStyle = '#fff2a6';
      g.lineWidth = 3;
      g.beginPath();
      g.arc(87, -26, 13 + kick * 5, -.9, .7);
      g.stroke();
    }
  }

  g.restore();
}

// Обновление счёта, рекорда и сезона
function updateHud() {
  $('hi').textContent = Math.floor(best);
  $('score').textContent = Math.floor(score);

  $('weather').textContent = runHardcore ? 'ХАРДКОР' : seasons[seasonIndex].name;
  $('weatherIcon').textContent = runHardcore ? '🌫️' : seasons[seasonIndex].icon;
}

// Рисование прямоугольника с закруглёнными углами
function roundedRect(g, x, y, w, h, r, fill) {
  r = Math.min(r, w / 2, h / 2);

  g.fillStyle = fill;
  g.beginPath();

  g.moveTo(x + r, y);
  g.lineTo(x + w - r, y);
  g.arcTo(x + w, y, x + w, y + r, r);

  g.lineTo(x + w, y + h - r);
  g.arcTo(x + w, y + h, x + w - r, y + h, r);

  g.lineTo(x + r, y + h);
  g.arcTo(x, y + h, x, y + h - r, r);

  g.lineTo(x, y + r);
  g.arcTo(x, y, x + r, y, r);

  g.closePath();
  g.fill();
}


  // Три карточки скинов
  function makeCards() {
  const box = $('cards');
  box.replaceChildren();

  skins.forEach((skin, i) => {
    const button = document.createElement('button');

    button.type = 'button';
    button.className =
      'skin-card' + (i === skinIndex ? ' selected' : '');

    button.innerHTML = `
      <canvas class="skin-preview" width="112" height="70"></canvas>
      <span>${skin.name}</span>
      <small>${skin.note}</small>
      <small class="skin-record">
        🏆 Рекорд: ${Math.floor(bestScores[i])}
      </small>
    `;

    const preview = button.querySelector('canvas');
    const p = preview.getContext('2d');

    drawDino(p, 17, 62, skin, false, 0, .62);

    button.addEventListener('click', () => {
      if (state !== 'menu' && state !== 'over') return;

      skinIndex = i;
      save('dinoSkin', i);
      makeCards();
    });

    box.appendChild(button);
  });
}

  function overlay(title, sub, buttonText, selectable, eyebrow) {
    $('achievementsPanel').classList.add('hidden');
    $('secretAchievementsPanel').classList.add('hidden');

$('eyebrow').style.display = '';
$('title').style.display = '';
$('sub').style.display = '';
$('startBtn').style.display = '';
document.querySelector('.help').style.display = '';

$('achievementsBtn').style.display =
  (state === 'menu' || state === 'over') ? '' : 'none';
    $('hardcoreBtn').style.display =
      (state === 'menu' || state === 'over') ? '' : 'none';
    $('crownBtn').style.display =
      (state === 'menu' || state === 'over') && crownUnlocked ? '' : 'none';
    $('title').innerHTML = title;
    $('sub').textContent = sub;
    $('startBtn').querySelector('span').textContent = buttonText;
    $('cards').style.display = selectable ? 'flex' : 'none';
    $('eyebrow').textContent = eyebrow || 'DINO RUNNER';

    if (selectable) makeCards();

    $('overlay').classList.remove('hidden');
  }

  function startOrResume() {
    if (state === 'pause') {
      state = 'play';
      $('overlay').classList.add('hidden');
      lastTime = 0;
      return;
    }

    if (state === 'menu' || state === 'over') {
      resetRun();
    }

    state = 'play';
    $('overlay').classList.add('hidden');
    lastTime = 0;
  }

  function pause() {
    if (state !== 'play') return;

    state = 'pause';

    overlay(
      'ПАУЗА',
      'Передохни немного — твой забег сохранён.',
      'Продолжить',
      false,
      'ПЕРЕРЫВ'
    );
  }

  function gameOver() {
  if (state !== 'play') return;

  state = 'over';

  // Обновляем рекорд выбранного скина
  if (score > bestScores[skinIndex]) {
    bestScores[skinIndex] = score;

    save(
      'dinoBestBySkin',
      JSON.stringify(bestScores)
    );
  }

  // Обновляем общий рекорд
  best = Math.max(best, score);
  save('dinoBest', best);

  updateHud();

  overlay(
    'ЗАБЕГ <span>ОКОНЧЕН</span>',
    'Твой результат: ' + Math.floor(score) + ' очков. Попробуешь ещё?',
    'Ещё раз',
    true,
    'НЕ СДАВАЙСЯ'
  );
}

// Препятствия
function spawnObstacle() {
  // В хардкоре валун появляется отдельным препятствием; он не ставится
  // вплотную к другому препятствию, так что остаётся время на удар.
  if (runHardcore && score > 500 && Math.random() < .22) {
    obstacles.push({
      type: 'boulder',
      x: W + 70,
      w: 88,
      h: 82,
      rotation: 0,
      broken: false,
      hitFlash: 0
    });
    return;
  }

  const r = Math.random();

  if (r < 0.36) {
    // Один кактус
    const h = 38 + Math.random() * 22;

    obstacles.push({
      type: 'cactus',
      x: W + 30,
      w: 34,
      h
    });

  } else if (r < 0.59) {
    // Тройные кактусы разной высоты
    obstacles.push({
      type: 'tripleCactus',
      x: W + 30,
      w: 91,
      h: 58,
      heights: [
        43 + Math.random() * 12,
        58 + Math.random() * 12,
        38 + Math.random() * 13
      ]
    });

  } else if (r < 0.80) {
    // Бревно с острыми шипами
    obstacles.push({
      type: 'spikedLog',
      x: W + 30,
      w: 76,
      h: 43
    });

  } else {
    // Птеродактиль: три варианта высоты
    const flightHeights = [
      44, // Низко — примерно на уровне кактусов
      68, // Средняя высота
      92  // Высоко
    ];

    const height = flightHeights[
      Math.floor(Math.random() * flightHeights.length)
    ];

    obstacles.push({
      type: 'ptero',
      x: W + 35,
      y: GROUND - height,
      w: 66,
      h: 46,
      flap: Math.random() * Math.PI * 2
    });
  }
}

  

function obstacleBox(o) {
  if (o.type === 'cactus') {
    return {
      x: o.x + 5,
      y: GROUND - o.h + 5,
      w: o.w - 9,
      h: o.h - 5
    };
  }

  if (o.type === 'tripleCactus') {
    return {
      x: o.x + 5,
      y: GROUND - Math.max(...o.heights) + 5,
      w: o.w - 10,
      h: Math.max(...o.heights) - 5
    };
  }

  if (o.type === 'spikedLog') {
    return {
      x: o.x + 5,
      y: GROUND - o.h - 3,
      w: o.w - 10,
      h: o.h + 3
    };
  }

  if (o.type === 'ptero') {
    return {
      x: o.x + 8,
      y: o.y - 30,
      w: 48,
      h: 28
    };
  }

  if (o.type === 'boulder') {
    return {
      x: o.x + 9,
      y: GROUND - o.h + 10,
      w: o.w - 18,
      h: o.h - 10
    };
  }

  return {
    x: o.x + 5,
    y: o.y - 19,
    w: 42,
    h: 18
  };
}


  function playerBox() {
    if (player.duck && player.grounded) {
      return {
        x: player.x + 8,
        y: GROUND - 36,
        w: 58,
        h: 31
      };
    }

    return {
      x: player.x + 14,
      y: player.y - 75,
      w: 52,
      h: 70
    };
  }

  function hit(a, b) {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  // Игровая логика
  function update(dt) {
    frame += dt;
    distance += speed * dt;
    score += speed * dt * .08;
    checkAchievements();
    if (runHardcore && !crownUnlocked && score >= 10000) {
      crownUnlocked = true;
      save('dinoCrownUnlocked', 1);
      updateCrownButton();
    }
    const baseSpeed = 6 + frame / 1200;
    speed = runHardcore
      ? Math.min(18, baseSpeed * 1.5)
      : Math.min(12.5, baseSpeed);

    player.duck = !!(keys.ArrowDown || keys.KeyS);
    player.run += dt;
    player.attackTimer = Math.max(0, (player.attackTimer || 0) - dt);

   if (!player.grounded) {
  player.vy += 0.68 * dt;
  player.y += player.vy * dt;

  if (player.y >= GROUND) {
    player.y = GROUND;
    player.vy = 0;
    player.grounded = true;
  }
}
    if (!obstacles.length) spawnObstacle();

    const last = obstacles[obstacles.length - 1];

    if (last.x + last.w < W - speed * dt * 58) {
      spawnObstacle();
    }

    obstacles.forEach(o => {
      o.x -= speed * dt;
      if (o.type === 'boulder') {
        o.rotation += speed * dt * .035;
        o.hitFlash = Math.max(0, (o.hitFlash || 0) - dt);
      }
    });
    obstacles = obstacles.filter(o => o.x + o.w > -20 && !o.broken);

    const box = playerBox();

    for (const o of obstacles) {
      if (hit(box, obstacleBox(o))) {
        gameOver();
        return;
      }
    }

   
// Сезон меняется каждые 1000 очков
const nextSeason = Math.floor(score / 1000) % 4;

if (nextSeason !== seasonIndex) {
  previousSeasonIndex = seasonIndex;
  seasonIndex = nextSeason;
  seasonBlend = 0;

  updateHud();

  // Частицы перехода сезона
  for (let i = 0; i < 24; i++) {
    particles.push({
      x: Math.random() * W,
      y: -Math.random() * H * .5,
      vx: (Math.random() - .5) * 2,
      vy: 1 + Math.random() * 2,
      life: 150 + Math.random() * 100,
      type: 'season'
    });
  }
}

// Плавность смены сезона
    seasonBlend = Math.min(1, seasonBlend + dt * .012);

    particles.forEach(p => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
    });

    particles = particles.filter(
      p => p.life > 0 && p.y < H + 30
    );

    updateHud();
  }

  // Фон: облака, горы, деревья

function drawCloud(x, y, s = 1, alpha = .8) {
  ctx.save();

  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  ctx.scale(s, s);

  // Мягкая тень под облаком
  ctx.fillStyle = 'rgba(90,110,135,0.16)';
  ctx.beginPath();
  ctx.ellipse(25, 8, 43, 12, 0, 0, Math.PI * 2);
  ctx.fill();

  // Нижний теневой слой
  ctx.fillStyle = '#dce5ef';
  ctx.beginPath();
  ctx.arc(0, 2, 17, 0, Math.PI * 2);
  ctx.arc(21, -5, 22, 0, Math.PI * 2);
  ctx.arc(46, 2, 16, 0, Math.PI * 2);
  ctx.fill();

  // Основное тело облака
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, -4, 16, 0, Math.PI * 2);
  ctx.arc(19, -14, 21, 0, Math.PI * 2);
  ctx.arc(43, -5, 16, 0, Math.PI * 2);
  ctx.arc(28, 0, 19, 0, Math.PI * 2);
  ctx.fill();

  // Светлые блики сверху
  ctx.fillStyle = 'rgba(255,255,255,0.75)';
  ctx.beginPath();
  ctx.ellipse(15, -25, 10, 4, -0.3, 0, Math.PI * 2);
  ctx.ellipse(34, -20, 8, 3, 0.2, 0, Math.PI * 2);
  ctx.fill();

  // Небольшой холодный оттенок снизу
  ctx.fillStyle = 'rgba(190,210,230,0.22)';
  ctx.beginPath();
  ctx.ellipse(25, 3, 27, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

  

function drawTree(x, y, scale, season, previousSeason = season, blend = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Палитра четырёх сезонов
  const palettes = [
    ['#ef9bbd', '#f5b4cc', '#d97fa5'], // Весна
    ['#4f9d62', '#70b979', '#347d4a'], // Лето
    ['#d77b3f', '#eea04d', '#a94e2d'], // Осень
    ['#e8f3fa', '#ffffff', '#b9d5e5']  // Зима
  ];

  const oldColors = palettes[previousSeason];
  const newColors = palettes[season];

  // Плавно смешиваем оттенки
  const colors = oldColors.map((color, i) =>
    mixColor(color, newColors[i], blend)
  );

  // Тень под кроной
  ctx.fillStyle = 'rgba(0,0,0,0.10)';
  ctx.beginPath();
  ctx.ellipse(2, -15, 29, 9, 0, 0, Math.PI * 2);
  ctx.fill();

  // Ствол
  ctx.fillStyle = '#72513c';
  ctx.fillRect(-5, -48, 10, 48);

  // Ветви
  ctx.strokeStyle = '#72513c';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';

  ctx.beginPath();
  ctx.moveTo(0, -32);
  ctx.lineTo(-13, -52);
  ctx.moveTo(0, -37);
  ctx.lineTo(14, -55);
  ctx.stroke();

  // Нижний слой кроны
  ctx.fillStyle = colors[2];
  ctx.beginPath();
  ctx.arc(-15, -43, 17, 0, Math.PI * 2);
  ctx.arc(15, -43, 18, 0, Math.PI * 2);
  ctx.arc(0, -49, 23, 0, Math.PI * 2);
  ctx.fill();

  // Основной слой кроны
  ctx.fillStyle = colors[0];
  ctx.beginPath();
  ctx.arc(0, -62, 22, 0, Math.PI * 2);
  ctx.arc(-14, -52, 16, 0, Math.PI * 2);
  ctx.arc(15, -52, 16, 0, Math.PI * 2);
  ctx.fill();

  // Светлые участки
  ctx.fillStyle = colors[1];
  ctx.beginPath();
  ctx.arc(-8, -70, 10, 0, Math.PI * 2);
  ctx.arc(10, -61, 8, 0, Math.PI * 2);
  ctx.arc(-20, -52, 6, 0, Math.PI * 2);
  ctx.fill();

  // Блики
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  ctx.beginPath();
  ctx.arc(-10, -74, 3, 0, Math.PI * 2);
  ctx.arc(5, -68, 2.5, 0, Math.PI * 2);
  ctx.arc(17, -55, 2, 0, Math.PI * 2);
  ctx.fill();

  // Весенние цветочки плавно появляются и исчезают
  const flowerAlpha =
    (previousSeason === 0 ? 1 - blend : 0) +
    (season === 0 ? blend : 0);

  if (flowerAlpha > 0) {
    ctx.save();
    ctx.globalAlpha *= flowerAlpha;
    ctx.fillStyle = '#fff0f7';

    for (let i = 0; i < 7; i++) {
      ctx.beginPath();
      ctx.arc(
        -17 + (i * 9) % 31,
        -72 + (i % 3) * 10,
        2.3,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }

    ctx.restore();
  }

  ctx.restore();
}



  
function drawMountain(x, y, w, h, color) {
  ctx.save();

  // Основной силуэт горы
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x - w / 2, y);

  ctx.lineTo(x - w * 0.34, y - h * 0.38);
  ctx.lineTo(x - w * 0.23, y - h * 0.32);
  ctx.lineTo(x - w * 0.12, y - h * 0.73);

  ctx.lineTo(x - w * 0.04, y - h * 0.62);
  ctx.lineTo(x + w * 0.04, y - h);
  ctx.lineTo(x + w * 0.15, y - h * 0.68);

  ctx.lineTo(x + w * 0.25, y - h * 0.76);
  ctx.lineTo(x + w * 0.36, y - h * 0.35);
  ctx.lineTo(x + w / 2, y);

  ctx.closePath();
  ctx.fill();

  // Освещённый левый склон
  ctx.fillStyle = 'rgba(255,255,255,0.13)';
  ctx.beginPath();
  ctx.moveTo(x - w * 0.12, y - h * 0.73);
  ctx.lineTo(x + w * 0.04, y - h);
  ctx.lineTo(x + w * 0.02, y - h * 0.58);
  ctx.lineTo(x - w * 0.13, y - h * 0.28);
  ctx.lineTo(x - w * 0.23, y - h * 0.32);
  ctx.closePath();
  ctx.fill();

  // Теневой склон
  ctx.fillStyle = 'rgba(0,0,0,0.10)';
  ctx.beginPath();
  ctx.moveTo(x + w * 0.04, y - h);
  ctx.lineTo(x + w * 0.15, y - h * 0.68);
  ctx.lineTo(x + w * 0.25, y - h * 0.76);
  ctx.lineTo(x + w * 0.36, y - h * 0.35);
  ctx.lineTo(x + w / 2, y);
  ctx.lineTo(x + w * 0.04, y);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}



// Дополнительные детали природного фона

function drawPine(x, y, scale, color) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  ctx.fillStyle = '#654b38';
  ctx.fillRect(-4, -42, 8, 42);

  ctx.fillStyle = color;

  for (let i = 0; i < 3; i++) {
    const top = -76 + i * 19;

    ctx.beginPath();
    ctx.moveTo(0, top - 27);
    ctx.lineTo(-20 + i * 3, top + 10);
    ctx.lineTo(20 - i * 3, top + 10);
    ctx.closePath();
    ctx.fill();
  }

  ctx.restore();
}

function drawBush(x, y, scale, color) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  ctx.fillStyle = color;

  ctx.beginPath();
  ctx.arc(-13, -7, 13, 0, Math.PI * 2);
  ctx.arc(0, -13, 17, 0, Math.PI * 2);
  ctx.arc(15, -7, 12, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(255,255,255,.15)';
  ctx.beginPath();
  ctx.arc(-4, -17, 5, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawFlower(x, y, color, scale = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  ctx.strokeStyle = '#4d8549';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -12);
  ctx.stroke();

  ctx.fillStyle = color;

  for (let i = 0; i < 5; i++) {
    const a = i * Math.PI * 2 / 5;

    ctx.beginPath();
    ctx.arc(
      Math.cos(a) * 4,
      -14 + Math.sin(a) * 4,
      3,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  ctx.fillStyle = '#f6d66d';
  ctx.beginPath();
  ctx.arc(0, -14, 2.5, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function mixColor(color1, color2, amount) {
  const a = parseInt(color1.slice(1), 16);
  const b = parseInt(color2.slice(1), 16);

  const r1 = (a >> 16) & 255;
  const g1 = (a >> 8) & 255;
  const b1 = a & 255;

  const r2 = (b >> 16) & 255;
  const g2 = (b >> 8) & 255;
  const b2 = b & 255;

  const r = Math.round(r1 + (r2 - r1) * amount);
  const g = Math.round(g1 + (g2 - g1) * amount);
  const blue = Math.round(b1 + (b2 - b1) * amount);

  return `rgb(${r}, ${g}, ${blue})`;
}

  function drawBackground() {
    const from = seasons[previousSeasonIndex];
const to = seasons[seasonIndex];

// Плавное ускорение и замедление перехода
const t = seasonBlend * seasonBlend * (3 - 2 * seasonBlend);

// Смешиваем цвета двух сезонов
const s = {
  sky1: mixColor(from.sky1, to.sky1, t),
  sky2: mixColor(from.sky2, to.sky2, t),
  hill1: mixColor(from.hill1, to.hill1, t),
  hill2: mixColor(from.hill2, to.hill2, t),
  ground: mixColor(from.ground, to.ground, t)
};

    const grad = ctx.createLinearGradient(0, 0, 0, GROUND);
    grad.addColorStop(0, s.sky1);
    grad.addColorStop(1, s.sky2);

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Солнце или зимняя луна
    ctx.save();
    ctx.globalAlpha = .9;
    ctx.fillStyle = seasonIndex === 3 ? '#f4f8ff' : '#ffe99b';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 28;

    ctx.beginPath();
    ctx.arc(790, 82, seasonIndex === 3 ? 24 : 31, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Дальние холмы — параллакс
    const shift = (distance * .12) % 420;

    for (let i = -1; i < 4; i++) {
      drawMountain(
        i * 420 - shift + 200,
        GROUND, 430, 100, s.hill1
      );
    }

    for (let i = -1; i < 5; i++) {
      drawMountain(
        i * 310 - (distance * .23) % 310 + 140,
        GROUND, 330, 65, s.hill2
      );
    }

    // Движущиеся облака
    for (let i = 0; i < 4; i++) {
      const x = (i * 280 - distance * .18) % (W + 150);
      drawCloud(
        x < -100 ? x + W + 150 : x,
        75 + (i % 2) * 38,
        .8 + (i % 2) * .2,
        .58
      );
    }

    // Деревья
    for (let i = 0; i < 6; i++) {
      const x = (i * 205 - distance * .42) % (W + 100);

      drawTree(
        x < -80 ? x + W + 100 : x,
        GROUND,
        .72 + (i % 3) * .12,
        seasonIndex
      );
    }

    
    // Прозрачность сезонных эффектов при переходе
    const autumnAlpha =
      (previousSeasonIndex === 2 ? 1 - t : 0) +
      (seasonIndex === 2 ? t : 0);

    const winterAlpha =
      (previousSeasonIndex === 3 ? 1 - t : 0) +
      (seasonIndex === 3 ? t : 0);

    const springAlpha =
      (previousSeasonIndex === 0 ? 1 - t : 0) +
      (seasonIndex === 0 ? t : 0);

    // Осенние листья
    if (autumnAlpha > 0) {
      ctx.save();
      ctx.globalAlpha *= autumnAlpha;

      for (let i = 0; i < 14; i++) {
        const x = (i * 83 - distance * .65) % (W + 40);
        const xx = x < 0 ? x + W + 40 : x;

        ctx.save();
        ctx.translate(xx, 125 + (i * 37) % 145);
        ctx.rotate(frame * .025 + i);

        ctx.fillStyle = i % 2 === 0 ? '#e88a42' : '#c85b32';
        ctx.beginPath();
        ctx.ellipse(0, 0, 5, 2.5, 0.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      ctx.restore();
    }

    // Зимний снег
    if (winterAlpha > 0) {
      ctx.save();
      ctx.globalAlpha *= winterAlpha;

      ctx.fillStyle = '#fff';

      for (let i = 0; i < 45; i++) {
        const x = (i * 97 - distance * .14) % (W + 20);
        const xx = x < 0 ? x + W + 20 : x;
        const y = (
          i * 53 + frame * (.6 + (i % 3) * .25)
        ) % (GROUND - 15);

        ctx.globalAlpha =
          winterAlpha * (.45 + (i % 4) * .12);

        ctx.beginPath();
        ctx.arc(xx, y, 1.5 + (i % 3), 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }

    // Весенние лепестки
    if (springAlpha > 0) {
      ctx.save();
      ctx.globalAlpha *= springAlpha;

      ctx.fillStyle = '#fff2f8';

      for (let i = 0; i < 12; i++) {
        const x = (i * 107 - distance * .3) % (W + 20);
        const xx = x < 0 ? x + W + 20 : x;
        const y = 95 + (i * 31 + frame * .5) % 175;

        ctx.beginPath();
        ctx.arc(xx, y, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }


    // Земля
    ctx.fillStyle = s.ground;
    ctx.fillRect(0, GROUND, W, H - GROUND);

    ctx.fillStyle = seasonIndex === 3 ? '#fff' : '#6b7950';
    ctx.fillRect(0, GROUND, W, 4);

    ctx.fillStyle = seasonIndex === 3 ? '#c4d8e5' : '#9a8b61';

    for (let i = 0; i < 32; i++) {
      const x = (i * 39 - distance * .9) % W;

      ctx.globalAlpha = .5;
      ctx.fillRect(
        x < 0 ? x + W : x,
        GROUND + 23 + (i % 3) * 13,
        14, 2
      );
    }

    ctx.globalAlpha = 1;
  }

  
function drawOneCactus(x, h, scale = 1) {
  ctx.save();
  ctx.translate(x, GROUND);
  ctx.scale(scale, 1);

  // Основной ствол с градиентом
  const body = ctx.createLinearGradient(-7, 0, 10, 0);
  body.addColorStop(0, '#145c39');
  body.addColorStop(.35, '#32b96b');
  body.addColorStop(.7, '#20a45b');
  body.addColorStop(1, '#0c653e');

  // Ствол
  roundedRect(ctx, -7, -h, 16, h, 7, body);

  // Светлый блик
  ctx.fillStyle = 'rgba(190,255,188,.55)';
  roundedRect(ctx, -4, -h + 7, 3, h - 15, 2, 'rgba(190,255,188,.55)');

  // Ребристая текстура
  ctx.strokeStyle = 'rgba(7,70,42,.55)';
  ctx.lineWidth = 1.5;

  for (let y = -h + 10; y < -7; y += 10) {
    ctx.beginPath();
    ctx.moveTo(-1, y);
    ctx.lineTo(2, y + 3);
    ctx.stroke();
  }

  // Боковые отростки
  const arms = [
    { x: -13, y: -h * .58, dir: -1 },
    { x: 10, y: -h * .78, dir: 1 }
  ];

  arms.forEach(a => {
    ctx.save();
    ctx.translate(a.x, a.y);

    const armGrad = ctx.createLinearGradient(-4, 0, 8, 0);
    armGrad.addColorStop(0, '#12623d');
    armGrad.addColorStop(.5, '#37bd70');
    armGrad.addColorStop(1, '#167347');

    roundedRect(ctx, -4, -3, 10, 8, 4, armGrad);
    roundedRect(ctx, a.dir * 3, -17, 7, 19, 4, armGrad);

    ctx.fillStyle = 'rgba(205,255,190,.6)';
    ctx.fillRect(a.dir * 3 + 1, -14, 2, 10);

    ctx.restore();
  });

  // Маленькие золотистые колючки
  ctx.strokeStyle = '#eaff9c';
  ctx.lineWidth = 1.4;

  for (let y = -h + 12; y < -7; y += 9) {
    ctx.beginPath();
    ctx.moveTo(-7, y);
    ctx.lineTo(-12, y - 3);
    ctx.moveTo(9, y + 3);
    ctx.lineTo(14, y);
    ctx.stroke();
  }

  // Основание и тень
  ctx.fillStyle = 'rgba(14,58,39,.25)';
  ctx.beginPath();
  ctx.ellipse(1, 0, 18, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}


function drawSpikedLog(o) {
  ctx.save();
  ctx.translate(o.x, GROUND);

  // Тень
  ctx.fillStyle = 'rgba(30,24,18,.25)';
  ctx.beginPath();
  ctx.ellipse(38, 2, 43, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Основное тело бревна
  const wood = ctx.createLinearGradient(0, -45, 0, 0);
  wood.addColorStop(0, '#d99a54');
  wood.addColorStop(.35, '#a96335');
  wood.addColorStop(.7, '#784126');
  wood.addColorStop(1, '#4d2c20');

  roundedRect(ctx, 0, -32, 76, 28, 9, wood);

  // Верхний светлый блик
  ctx.strokeStyle = '#f2bd79';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(9, -28);
  ctx.quadraticCurveTo(37, -35, 66, -27);
  ctx.stroke();

  // Текстура коры
  ctx.strokeStyle = 'rgba(58,29,18,.65)';
  ctx.lineWidth = 2;

  for (let i = 0; i < 5; i++) {
    const x = 12 + i * 13;

    ctx.beginPath();
    ctx.moveTo(x, -24);
    ctx.quadraticCurveTo(x - 5, -16, x + 1, -9);
    ctx.stroke();
  }

  // Кольца на торце
  ctx.strokeStyle = '#e8b477';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(4, -18, 5, 10, 0, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeStyle = '#63391f';
  ctx.beginPath();
  ctx.ellipse(4, -18, 2, 6, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Острые шипы на верхней стороне
  const spikes = [
    { x: 17, h: 15 },
    { x: 31, h: 21 },
    { x: 46, h: 17 },
    { x: 60, h: 13 }
  ];

  spikes.forEach(s => {
    const grad = ctx.createLinearGradient(
      s.x - 5, -32 - s.h,
      s.x + 4, -32
    );

    grad.addColorStop(0, '#f7f0c9');
    grad.addColorStop(.45, '#b9c2bd');
    grad.addColorStop(1, '#52616a');

    ctx.fillStyle = grad;
    ctx.strokeStyle = '#37434a';
    ctx.lineWidth = 1;

    ctx.beginPath();
    ctx.moveTo(s.x - 6, -29);
    ctx.lineTo(s.x, -32 - s.h);
    ctx.lineTo(s.x + 6, -29);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Блик на каждом шипе
    ctx.strokeStyle = 'rgba(255,255,255,.8)';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(s.x - 2, -31);
    ctx.lineTo(s.x, -32 - s.h + 5);
    ctx.stroke();
  });

  ctx.restore();
}

function drawCactus(o) {
  if (o.type === 'tripleCactus') {
    drawOneCactus(o.x + 12, o.heights[0], .9);
    drawOneCactus(o.x + 40, o.heights[1], 1.05);
    drawOneCactus(o.x + 68, o.heights[2], .85);
  } else {
    drawOneCactus(o.x + 10, o.h, 1);
  }
}


  
function drawPtero(o) {
  const flap = Math.sin(frame * .28) * 9;

  ctx.save();
  ctx.translate(o.x, o.y);

  // Хвост сзади
  ctx.fillStyle = '#59409d';
  ctx.beginPath();
  ctx.moveTo(39, -7);
  ctx.lineTo(58, -13);
  ctx.lineTo(47, -2);
  ctx.closePath();
  ctx.fill();

  // Дальнее крыло
  ctx.fillStyle = '#8065c9';
  ctx.beginPath();
  ctx.moveTo(22, -13);
  ctx.lineTo(35, -40 - flap);
  ctx.lineTo(44, -16);
  ctx.lineTo(35, -8);
  ctx.closePath();
  ctx.fill();

  // Тело
  const body = ctx.createLinearGradient(0, -25, 0, 5);
  body.addColorStop(0, '#a58ae9');
  body.addColorStop(1, '#5945a5');

  roundedRect(ctx, 7, -19, 39, 20, 9, body);

  // Шея и голова спереди
  ctx.fillStyle = '#b39af0';
  ctx.beginPath();
  ctx.ellipse(10, -17, 10, 9, -.2, 0, Math.PI * 2);
  ctx.fill();

  // Клюв направлен влево
  const beak = ctx.createLinearGradient(-15, -15, 5, -8);
  beak.addColorStop(0, '#ffcf5b');
  beak.addColorStop(1, '#e88a32');

  ctx.fillStyle = beak;
  ctx.beginPath();
  ctx.moveTo(5, -17);
  ctx.lineTo(-13, -12);
  ctx.lineTo(5, -8);
  ctx.closePath();
  ctx.fill();

  // Глаз — СПЕРЕДИ, рядом с клювом
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(7, -23, 4.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#1d1838';
  ctx.beginPath();
  ctx.arc(5.5, -23, 2.1, 0, Math.PI * 2);
  ctx.fill();

  // Блик глаза
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(5, -24, .8, 0, Math.PI * 2);
  ctx.fill();

  // Ближнее крыло
  ctx.fillStyle = '#b09aef';
  ctx.beginPath();
  ctx.moveTo(20, -14);
  ctx.lineTo(30, -42 + flap);
  ctx.lineTo(39, -18);
  ctx.lineTo(31, -7);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = '#745db9';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(21, -14);
  ctx.lineTo(30, -31 + flap);
  ctx.moveTo(27, -12);
  ctx.lineTo(35, -25 + flap);
  ctx.stroke();

  // Ноги
  ctx.strokeStyle = '#e6a34e';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(25, -1);
  ctx.lineTo(22, 4);
  ctx.lineTo(17, 4);
  ctx.moveTo(37, -1);
  ctx.lineTo(34, 4);
  ctx.lineTo(29, 4);
  ctx.stroke();

  ctx.restore();
}


 
function drawBoulder(o) {
  ctx.save();
  ctx.translate(o.x + o.w / 2, GROUND - o.h / 2 + 2);
  ctx.rotate(o.rotation || 0);
  const r = o.w * .43;
  const grad = ctx.createRadialGradient(-r * .35, -r * .4, 4, 0, 0, r * 1.2);
  grad.addColorStop(0, '#aeb3b2');
  grad.addColorStop(.45, '#69716f');
  grad.addColorStop(1, '#303a3a');
  ctx.fillStyle = grad;
  ctx.strokeStyle = '#202a2a';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = '#c4cbc5';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-20, -12); ctx.lineTo(-7, -25); ctx.lineTo(5, -19);
  ctx.moveTo(9, 15); ctx.lineTo(23, 4);
  ctx.moveTo(-24, 12); ctx.lineTo(-14, 20);
  ctx.stroke();
  if (o.hitFlash > 0) {
    ctx.strokeStyle = '#fff1a8';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.arc(0, 0, r + 7, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function drawObstacle(o) {
  if (o.type === 'cactus' || o.type === 'tripleCactus') {
    drawCactus(o);
  } else if (o.type === 'spikedLog') {
    drawSpikedLog(o);
  } else if (o.type === 'ptero') {
    drawPtero(o);
  } else if (o.type === 'boulder') {
    drawBoulder(o);
  }
}

  
function draw() {
  drawBackground();

  // Игровые препятствия
  obstacles.forEach(drawObstacle);

  // Персонаж
  drawDino(
    ctx,
    player.x,
    player.y,
    skins[skinIndex],
    player.duck,
    player.run,
    1
  );

  if (runHardcore) {
    const nearbyRock = obstacles.find(o =>
      o.type === 'boulder' && o.x < player.x + 250 && o.x > player.x + 55
    );
    if (nearbyRock) {
      ctx.save();
      ctx.font = '900 16px Manrope, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fff0a6';
      ctx.shadowColor = '#000';
      ctx.shadowBlur = 7;
      ctx.fillText('→ ПРОБИТЬ!', player.x + 95, GROUND - 112);
      ctx.restore();
    }
  }

  // Частицы перехода сезона
  particles.forEach(p => {
    if (p.type === 'rock') {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.life / 60);
      ctx.fillStyle = '#8d9693';
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + 7, p.y - 5);
      ctx.lineTo(p.x + 11, p.y + 3);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      return;
    }
    if (p.type !== 'season') return;

    ctx.save();
    ctx.globalAlpha = Math.max(0, p.life / 250);
    ctx.fillStyle = '#fff0d8';

    ctx.beginPath();
    ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });

  // Мягкая виньетка
  const v = ctx.createLinearGradient(0, 0, 0, H);
  v.addColorStop(0, 'rgba(10,24,40,.04)');
  v.addColorStop(1, 'rgba(10,24,40,.12)');

  ctx.fillStyle = v;
  ctx.fillRect(0, 0, W, H);

  // Туман/темнота режима хардкор: центр немного светлее,
  // края почти полностью затемнены.
  if (runHardcore && (state === 'play' || state === 'pause')) {
    const fog = ctx.createRadialGradient(player.x + 55, player.y - 45, 65,
      player.x + 55, player.y - 45, 390);
    fog.addColorStop(0, 'rgba(8, 13, 24, .10)');
    fog.addColorStop(.42, 'rgba(8, 13, 24, .52)');
    fog.addColorStop(1, 'rgba(3, 7, 15, .94)');
    ctx.fillStyle = fog;
    ctx.fillRect(0, 0, W, H);
    // Лёгкие полосы тумана
    ctx.fillStyle = 'rgba(190, 205, 220, .08)';
    for (let i = 0; i < 5; i++) {
      const fx = (i * 245 - distance * .35) % (W + 260);
      ctx.fillRect(fx < -200 ? fx + W + 260 : fx, 230 + i * 24, 180, 18);
    }
  }
}


  function jump() {
    if (state !== 'play' || !player.grounded || player.duck) return;

    player.vy = -12.5;
    player.grounded = false;
  }

  function punch() {
    if (state !== 'play' || !runHardcore) return;
    player.attackTimer = 18;
    player.attackType = 'kick';

    const target = obstacles.find(o =>
      o.type === 'boulder' && !o.broken &&
      o.x < player.x + 205 && o.x + o.w > player.x + 45
    );

    if (!target) return;

    // Удар срабатывает только в коротком окне перед столкновением.
    if (target.x > player.x + 155 || target.x < player.x + 75) return;

    target.broken = true;
    for (let i = 0; i < 18; i++) {
      particles.push({
        x: target.x + target.w / 2,
        y: GROUND - target.h / 2,
        vx: (Math.random() - .5) * 8,
        vy: (Math.random() - .8) * 7,
        life: 35 + Math.random() * 25,
        type: 'rock'
      });
    }
  }

  function updateCrownButton() {
    const button = $('crownBtn');
    button.hidden = !crownUnlocked;
    button.textContent = crownEquipped ? '👑 Снять корону' : '👑 Надеть корону';
    button.classList.toggle('equipped', crownEquipped);
  }
// Выбор режима доступен только до начала забега
$('hardcoreBtn').addEventListener('click', () => {
  if (state !== 'menu' && state !== 'over') return;
  hardcoreSelected = !hardcoreSelected;
  $('hardcoreBtn').textContent = hardcoreSelected
    ? '⚡ ХАРДКОР: ВКЛЮЧЁН'
    : '⚡ ХАРДКОР: ВЫКЛ';
  $('hardcoreBtn').classList.toggle('active', hardcoreSelected);
  $('hardcoreBtn').setAttribute('aria-pressed', String(hardcoreSelected));
});

$('crownBtn').addEventListener('click', () => {
  if (!crownUnlocked || (state !== 'menu' && state !== 'over')) return;
  crownEquipped = !crownEquipped;
  save('dinoCrownEquipped', crownEquipped ? 1 : 0);
  updateCrownButton();
  makeCards();
});

// Открыть достижения
$('achievementsBtn').addEventListener('click', () => {
  renderAchievements();

  $('eyebrow').style.display = 'none';
  $('title').style.display = 'none';
  $('sub').style.display = 'none';
  $('cards').style.display = 'none';
  $('startBtn').style.display = 'none';
  $('achievementsBtn').style.display = 'none';
  $('hardcoreBtn').style.display = 'none';
  $('crownBtn').style.display = 'none';

  document.querySelector('.help').style.display = 'none';

  $('achievementsPanel').classList.remove('hidden');
  $('secretAchievementsPanel').classList.add('hidden');
});

$('secretAchievementsBtn').addEventListener('click', () => {
  $('achievementsPanel').classList.add('hidden');
  $('secretAchievementsPanel').classList.remove('hidden');
  renderAchievements();
});

$('secretAchievementsBackBtn').addEventListener('click', () => {
  $('secretAchievementsPanel').classList.add('hidden');
  $('achievementsPanel').classList.remove('hidden');
});

// Вернуться в главное меню
$('achievementsBackBtn').addEventListener('click', () => {
  $('achievementsPanel').classList.add('hidden');
  $('secretAchievementsPanel').classList.add('hidden');

  $('eyebrow').style.display = '';
  $('title').style.display = '';
  $('sub').style.display = '';
  $('startBtn').style.display = '';
  document.querySelector('.help').style.display = '';

  $('achievementsBtn').style.display =
    (state === 'menu' || state === 'over') ? '' : 'none';
  $('hardcoreBtn').style.display =
    (state === 'menu' || state === 'over') ? '' : 'none';
  $('crownBtn').style.display =
    (state === 'menu' || state === 'over') && crownUnlocked ? '' : 'none';

  if (state === 'menu' || state === 'over') {
    makeCards();
  }
});

  $('startBtn').addEventListener('click', startOrResume);

  window.addEventListener('keydown', e => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (keys[e.code]) return;
    keys[e.code] = true;

    if (e.code === 'KeyP' || e.code === 'Escape') {
      if (state === 'play') pause();
      else if (state === 'pause') startOrResume();
      return;
    }

    if (state === 'play' && e.code === 'ArrowRight') {
      punch();
      return;
    }

    if ((state === 'menu' || state === 'over') && e.code === 'ArrowLeft') {
      skinIndex = (skinIndex + 2) % 3;
      save('dinoSkin', skinIndex);
      makeCards();
    } else if ((state === 'menu' || state === 'over') && e.code === 'ArrowRight') {
      skinIndex = (skinIndex + 1) % 3;
      save('dinoSkin', skinIndex);
      makeCards();
    } else if (
      e.code === 'Space' ||
      e.code === 'ArrowUp' ||
      e.code === 'KeyW'
    ) {
      if (state === 'menu' || state === 'over') startOrResume();
      else jump();
    } else if (e.code === 'Enter' && state !== 'play') {
      startOrResume();
    }
  });

  window.addEventListener('keyup', e => {
    keys[e.code] = false;
  });

  // Управление на телефоне
  let pointerDuck = false;

  canvas.addEventListener('pointerdown', e => {
    if (state !== 'play') return;

    const r = canvas.getBoundingClientRect();
    const y = (e.clientY - r.top) / r.height;

    const x = (e.clientX - r.left) / r.width;
    if (runHardcore && x > .78 && y < .62) {
      punch();
    } else if (y > .68) {
      pointerDuck = true;
      keys.ArrowDown = true;
    } else {
      jump();
    }
  });

  window.addEventListener('pointerup', () => {
    if (pointerDuck) {
      pointerDuck = false;
      keys.ArrowDown = false;
    }
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state === 'play') pause();
  });

  // Главный игровой цикл
  function loop(t) {
    const dt = lastTime
      ? Math.min(2.5, (t - lastTime) / 16.667)
      : 1;

    lastTime = t;

    if (state === 'play') update(dt);

    draw();
    requestAnimationFrame(loop);
  }

  // Инициализация
  resetRun();
  updateHud();
  $('hardcoreBtn').textContent = hardcoreSelected
    ? '⚡ ХАРДКОР: ВКЛЮЧЁН'
    : '⚡ ХАРДКОР: ВЫКЛ';
  $('hardcoreBtn').classList.toggle('active', hardcoreSelected);
  updateCrownButton();

  overlay(
    'DINO <span>RUNNER</span>',
    'Выбери один из трёх скинов динозаврика',
    'Начать забег',
    true,
    'ГОТОВ К ПРИКЛЮЧЕНИЮ?'
  );

  requestAnimationFrame(loop);
})();
